<?php

namespace App\Http\Controllers\Client;

use App\Helpers\Client;
use App\Helpers\LogActivity;
use App\Helpers\Password;
use App\Helpers\Sanitize;
use App\Helpers\Validate;
use App\Http\Controllers\Controller;
use App\Models\Client as ModelsClient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Session\Session;
use Validator;
use Illuminate\Support\Facades\Log;
use Exception;


class ProfileController extends Controller
{
//    public function EditAccountDetails()
//    {
//       $auth = Auth::user();
//       $initCountries = new Client();
//       $countries = $initCountries->getCountries();

//       return view('pages.profile.editaccountdetails.index', ['auth' => $auth, 'countries' => $countries]);
//    }
    public function EditAccountDetails()
    {
        try {
            $auth = Auth::user();
            if (!$auth) {
                return redirect('/login');
            }

            $initCountries = new Client();
            $countries = $initCountries->getCountries();

            return view('pages.profile.editaccountdetails.index', [
                'auth' => $auth, 
                'countries' => $countries
            ]);
        } catch (Exception $e) {
            return redirect('/login');
        }
    }

   public function UpdateAccountDetails(Request $request)
   {

      $rules = [
         'firstName'  => 'required',
         'lastName'   => 'required',
         'companyName'   => 'required',
         'email'   => 'required',
         'phone'   => 'required',
         'address1'   => 'required',
         'address2'   => 'nullable',
         'city'   => 'required',
         'state'   => 'required',
         'postalCode'   => 'required',
         'country'   => 'required',
      ];
      $messages = [
         'firstName.required'    => 'Name required.',
         'lastName.required'    => 'Last Name required.',
         'companyName.required'    => 'Company Name required.',
         'email.required'    => 'Email required.',
         'phone.required'    => 'Phone required.',
         'address1.required'    => 'Address required.',
         'city.required'    => 'City required.',
         'state.required'    => 'State required.',
         'postalCode.required'    => 'Postal Code required.',
         'country.required'    => 'Country required.',
      ];
      $validator = Validator::make($request->all(), $rules, $messages);
      if ($validator->fails()) {
         return redirect()->back()->withErrors($validator)->withInput($request->all())->with(['error' => $messages]);
      }

      $id = $request->userid;
      $updateClient = ModelsClient::findOrFail($id);
      $updateClient->firstname = $request->firstName;
      $updateClient->lastname = $request->lastName;
      $updateClient->companyname = $request->companyName;
      $updateClient->email = $request->email;
      $updateClient->phonenumber = $request->phone;
      $updateClient->address1 = $request->address1;
      $updateClient->address2 = $request->address2 ?? "";
      $updateClient->city = $request->city;
      $updateClient->state = $request->state;
      $updateClient->postcode = $request->postalCode;
      $updateClient->country = $request->country;
      $updateClient->save();
      return redirect()->back()->withErrors($validator)->withInput()->with(['success' => 'Profile Updated!']);
   }

   public function UpdatePassword(Request $request)
   {
      $auth = Auth::user();
      $validate = new Validate();
      $hasher = new Password();

      $prevPassword = Sanitize::decode($request->prevPassword);
      $newPassword = Sanitize::decode($request->newPassword);
      $confirmPassword = Sanitize::decode($request->confirmPassword);
      $userid = $auth->id;

      $getPasswords = ModelsClient::select('password')->where('id', $userid)->get();
      foreach ($getPasswords as $pw) {
         $storedPassHash = $pw->password;
      }

      $checkPrevPassword = $hasher->verify($prevPassword, $storedPassHash);
      $errMsg = [];
      if (!$checkPrevPassword) {
         $errMsg[] = __('client.existingpasswordincorrect');
      }
      if ($newPassword !== $confirmPassword) {
         $errMsg[] = __('client.clientareaerrorpasswordnotmatch');
      }
      if (!$confirmPassword) {
         $errMsg[] = __('client.clientareaerrorpasswordconfirm');
      }

      if ($errMsg) {
         return redirect()->back()->with('error_pass', $errMsg);
      } else {
         $updatedPassword = $hasher->hash($newPassword);
         $updateClient = ModelsClient::findOrFail($userid);
         $updateClient->password = $updatedPassword;
         $updateClient->save();
         \App\Helpers\Hooks::run_hook("ClientChangePassword", array("userid" => $userid, "password" => $newPassword));
         LogActivity::Save("Modified Password - User ID: " . $userid);
         return redirect()->route('pages.profile.changepassword.index')->with('success_pass', "Password has been changed!");
      }
   }

   public function EmailNotes()
   {
      $auth = Auth::user();
      return view('pages.profile.emailnotes.index');
   }

//    public function SecuritySettings(Request $request)
//    {
//       $auth = Auth::guard('web')->user();
//       $legacyClient = new \App\Helpers\ClientClass($auth->id);

//       $smartyvalues = []; // Inisialisasi array
//       $smartyvalues["errormessage"] = "";
//       if (!session("cid")) {
//         if ($request->input("toggle_sso")) {
//             $client = $auth;
//             $client->allowSso = (bool) $request->input("allow_sso");
//             $client->save();
//         }
//         $smartyvalues["successful"] = $request->input("successful") ? true : false;
//         $twofa = new \App\Helpers\TwoFactorAuthentication();
//         $twofa->setClientID($auth->id);
//         if ($twofa->isActiveClients()) {
//             $twoFactorAuthEnabled = $twofa->isEnabled();
//             $smartyvalues["twoFactorAuthAvailable"] = true;
//             $smartyvalues["twoFactorAuthEnabled"] = $twoFactorAuthEnabled;
//             $smartyvalues["twofaavailable"] = true;
//             $smartyvalues["twofastatus"] = $twoFactorAuthEnabled;
//         }
//          $securityquestions = (new \App\Helpers\Client)->getSecurityQuestions("");
//          $smartyvalues["securityquestions"] = $securityquestions;
//          $smartyvalues["securityquestionsenabled"] = count($securityquestions) ? true : false;
//          $clientsdetails = \App\Helpers\ClientHelper::getClientsDetails($legacyClient->getID());
//          if ($clientsdetails["securityqid"] == 0) {
//             $smartyvalues["nocurrent"] = true;
//          } else {
//             foreach ($securityquestions as $values) {
//                if ($values["id"] == $clientsdetails["securityqid"]) {
//                   $smartyvalues["currentquestion"] = $values["question"];
//                }
//             }
//          }
//          $errormessage = "";
//          if ($request->input("submit")) {
//             $currentsecurityqans = $request->input("currentsecurityqans");
//             $securityqans = $request->input("securityqans");
//             $securityqans2 = $request->input("securityqans2");
//             if ($clientsdetails["securityqid"] && $clientsdetails["securityqans"] != $currentsecurityqans) {
//                $errormessage .= "<li>" . \Lang::get("client.securitycurrentincorrect");
//             }
//             if (!$securityqans) {
//                $errormessage .= "<li>" . \Lang::get("client.securityanswerrequired");
//             }
//             if ($securityqans != $securityqans2) {
//                $errormessage .= "<li>" . \Lang::get("client.securitybothnotmatch");
//             }
//             if (!$errormessage) {
//                \App\Models\Client::where(array("id" => $legacyClient->getID()))->update(array("securityqid" => $securityqid, "securityqans" => (new \App\Helpers\Pwd)->encrypt($securityqans)));
//                \App\Helpers\LogActivity::Save("Modified Security Question - User ID: " . $legacyClient->getID());
//                // redir("action=changesq&successful=true");
//                return redirect()->route('pages.profile.securitysettings.index', ['action' => 'changesq', 'successful' => 'true']);
//             }
//          }
//          $smartyvalues["errormessage"] = $errormessage;
//          $smartyvalues["showSsoSetting"] = 1 <= \App\Models\AppLink::whereIsEnabled(1)->count();
//          $smartyvalues["isSsoEnabled"] = $auth->allowSso;
//       } else {
//         $smartyvalues["twofaavailable"] = false;
//         $smartyvalues["twofaactivation"] = true;
//         $smartyvalues["securityquestionsenabled"] = false;
//         $smartyvalues["showSsoSetting"] = false;
//       }
      
//       return view('pages.profile.securitysettings.index', [
//         'twoFactorAuthEnabled' => false,
//         'twoFactorAuthAvailable' => true,
//         'smartyvalues' => $smartyvalues // Pass sebagai array
//     ]);
//    }

public function SecuritySettings(Request $request)
{
    try {
        // Get authenticated user
        $auth = Auth::guard('web')->user();
        if (!$auth) {
            throw new \Exception('User not authenticated');
        }

        $legacyClient = new \App\Helpers\ClientClass($auth->id);
        $smartyvalues = [
            'errormessage' => '',
            'successful' => false,
            'twofaavailable' => false,
            'twoFactorAuthEnabled' => false,
            'twoFactorAuthAvailable' => false,
            'twofastatus' => false,
            'securityquestionsenabled' => false,
            'showSsoSetting' => false,
            'isSsoEnabled' => false,
            'nocurrent' => false
        ];

        // Handle non-client session
        if (!session("cid")) {
            // Handle SSO toggle
            if ($request->input("toggle_sso")) {
                $auth->allowSso = (bool) $request->input("allow_sso");
                $auth->save();
            }

            // Set success status from request
            $smartyvalues['successful'] = (bool) $request->input("successful");

            // Initialize 2FA
            $twofa = new \App\Helpers\TwoFactorAuthentication();
            $twofa->setClientID($auth->id);

            // Check 2FA status
            if ($twofa->isActiveClients()) {
                $twoFactorAuthEnabled = $twofa->isEnabled();
                $smartyvalues['twoFactorAuthAvailable'] = true;
                $smartyvalues['twoFactorAuthEnabled'] = $twoFactorAuthEnabled;
                $smartyvalues['twofaavailable'] = true;
                $smartyvalues['twofastatus'] = $twoFactorAuthEnabled;
            }

            // Get security questions
            $securityQuestions = (new \App\Helpers\Client)->getSecurityQuestions("");
            $smartyvalues['securityquestions'] = $securityQuestions;
            $smartyvalues['securityquestionsenabled'] = !empty($securityQuestions);

            // Get client details
            $clientsDetails = \App\Helpers\ClientHelper::getClientsDetails($legacyClient->getID());
            
            // Handle security questions
            if (empty($clientsDetails['securityqid'])) {
                $smartyvalues['nocurrent'] = true;
            } else {
                foreach ($securityQuestions as $values) {
                    if ($values['id'] == $clientsDetails['securityqid']) {
                        $smartyvalues['currentquestion'] = $values['question'];
                        break;
                    }
                }
            }

            // Handle form submission
            if ($request->input('submit')) {
                $errormessage = $this->handleSecurityQuestionSubmission(
                    $request,
                    $clientsDetails,
                    $legacyClient
                );
                
                if (empty($errormessage)) {
                    return redirect()
                        ->route('pages.profile.securitysettings.index', [
                            'action' => 'changesq',
                            'successful' => 'true'
                        ]);
                }
                
                $smartyvalues['errormessage'] = $errormessage;
            }

            // Set SSO settings
            $smartyvalues['showSsoSetting'] = 1 <= \App\Models\AppLink::whereIsEnabled(1)->count();
            $smartyvalues['isSsoEnabled'] = $auth->allowSso;

        } else {
            // Default values for client session
            $smartyvalues['twofaactivation'] = true;
        }

        // Log debug information
        \Log::info('Security Settings Status:', [
            'userId' => $auth->id,
            'twoFactorAuthEnabled' => $smartyvalues['twoFactorAuthEnabled'],
            'twoFactorAuthAvailable' => $smartyvalues['twoFactorAuthAvailable']
        ]);

        return view('pages.profile.securitysettings.index', [
            'twoFactorAuthEnabled' => $smartyvalues['twoFactorAuthEnabled'],
            'twoFactorAuthAvailable' => $smartyvalues['twoFactorAuthAvailable'],
            'smartyvalues' => $smartyvalues
        ]);

    } catch (\Exception $e) {
        \Log::error('Security Settings Error:', [
            'message' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);

        return redirect()
            ->back()
            ->with('error', 'An error occurred while loading security settings.');
    }
}

/**
 * Handle security question form submission
 */
private function handleSecurityQuestionSubmission($request, $clientsDetails, $legacyClient)
{
    $errormessage = '';
    
    $currentsecurityqans = $request->input('currentsecurityqans');
    $securityqans = $request->input('securityqans');
    $securityqans2 = $request->input('securityqans2');
    $securityqid = $request->input('securityqid');

    // Validate current answer
    if ($clientsDetails['securityqid'] && $clientsDetails['securityqans'] != $currentsecurityqans) {
        $errormessage .= "<li>" . \Lang::get("client.securitycurrentincorrect");
    }

    // Validate new answer
    if (empty($securityqans)) {
        $errormessage .= "<li>" . \Lang::get("client.securityanswerrequired");
    }

    // Validate answer confirmation
    if ($securityqans !== $securityqans2) {
        $errormessage .= "<li>" . \Lang::get("client.securitybothnotmatch");
    }

    // Update if no errors
    if (empty($errormessage)) {
        \App\Models\Client::where([
            'id' => $legacyClient->getID()
        ])->update([
            'securityqid' => $securityqid,
            'securityqans' => (new \App\Helpers\Pwd)->encrypt($securityqans)
        ]);

        \App\Helpers\LogActivity::Save(
            "Modified Security Question - User ID: " . $legacyClient->getID()
        );
    }

    return $errormessage;
}


   public function enableTwoFactor(Request $request)
{
    try {
        $auth = Auth::guard('web')->user();
        $twofa = new \App\Helpers\TwoFactorAuthentication();
        $twofa->setClientID($auth->id);
        
        // Aktifkan 2FA
        $twofa->enable();
        
        // Log aktivitas
        \App\Helpers\LogActivity::Save("Two-Factor Authentication Enabled - User ID: " . $auth->id);
        
        return redirect()->back()->with('success', 'Two Factor Authentication has been enabled successfully.');
    } catch (\Exception $e) {
        return redirect()->back()->with('error', 'Failed to enable Two Factor Authentication: ' . $e->getMessage());
    }
}

public function disableTwoFactor(Request $request)
{
    try {
        $auth = Auth::guard('web')->user();
        $twofa = new \App\Helpers\TwoFactorAuthentication();
        $twofa->setClientID($auth->id);
        
        // Nonaktifkan 2FA
        $twofa->disable();
        
        // Log aktivitas
        \App\Helpers\LogActivity::Save("Two-Factor Authentication Disabled - User ID: " . $auth->id);
        
        return redirect()->back()->with('success', 'Two Factor Authentication has been disabled successfully.');
    } catch (\Exception $e) {
        return redirect()->back()->with('error', 'Failed to disable Two Factor Authentication: ' . $e->getMessage());
    }
}
    
}