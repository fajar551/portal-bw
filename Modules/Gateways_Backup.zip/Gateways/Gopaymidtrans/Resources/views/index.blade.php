<button onclick="payNow()" class="btn btn-primary">{{$langpaynow}}</button>
{{-- modal snap --}}
<div class="modal fade" id="modalSnap" tabindex="-1" role="dialog" aria-labelledby="modalSnapTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        {{-- <div class="modal-header">
          <h5 class="modal-title" id="">3DS OTP</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div> --}}
        <div class="modal-body">
            <iframe height="450" width="100%" id="sample-inline-frame" name="sample-inline-frame"> </iframe>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
        </div>
      </div>
    </div>
</div>
{{-- snap js --}}
<script type="text/javascript" src="{{$snapJsUrl}}" data-client-key="{{$clientKey}}"></script>
<script>
    $(document).ready(function() {
        setInterval(update, 5000);
    });
    function update() {
        $.ajax({
            type : 'GET',
            url : "{{$url_update}}",
            data: {id: "{{$invoiceid}}", _token: "{{csrf_token()}}"},
            success : function(data){
                if(data.status){
                    location.reload();
                }	
            },
        });
    };
    function payNow() {
        snap.show();
        $.ajax({
            url: "{{$url}}",
            type: "post",
            data: {
                _token: "{{csrf_token()}}",
                invoiceid: "{{$invoiceid}}",
            },
            success: function(res) {
                snap.hide();
                console.log(res);
                if (res.result == 'error') {
                    alert(res.message);
                } else {
                    // location.href = res.redirect_url;
                    // window.open(res.redirect_url, 'sample-inline-frame', '', true);
                    // $('#modalSnap').modal('show');
                    var token = res.token;
                    snap.pay(token, {
                        onSuccess: function(result){
                            console.log('success');
                            console.log(result);
                            // location.reload();
                        },
                        onPending: function(result){
                            console.log('pending');
                            console.log(result);
                        },
                        onError: function(result){
                            console.log('error');
                            console.log(result);
                            alert(result.status_message);
                        },
                        onClose: function(){
                            console.log('customer closed the popup without finishing the payment');
                        }
                    })
                }
            },
            error: function() {
                snap.hide();
                console.log('error');
            },
        });
    }
</script>
