<?php

return [
    'name' => 'Gopaymidtrans'
];
