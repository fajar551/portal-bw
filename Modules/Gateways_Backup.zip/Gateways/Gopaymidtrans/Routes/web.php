<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('gopaymidtrans')->group(function() {
    Route::get('/', 'GopaymidtransController@index');
    Route::post('/payNow', 'GopaymidtransController@payNow');
    Route::match(['get', 'post'], '/callback', 'GopaymidtransController@callback');
    Route::get('/process_payment', 'GopaymidtransController@process_payment');
});
