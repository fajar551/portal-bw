<?php

namespace Modules\Gateways\Gopaymidtrans\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Auth;

class GopaymidtransController extends Controller
{   
    function MetaData()
    {
        return array(
            'DisplayName' => 'GoPay Midtrans',
            'APIVersion' => '1.1', // Use API Version 1.1
            'DisableLocalCreditCardInput' => true,
            'TokenisedStorage' => false,
        );
    }

    function config()
    {
        return [
            'FriendlyName' => array(
                'Type' => 'System',
                'Value' => 'GoPay Midtrans',
            ),
            "UsageNotes" => array(
                "Type" => "System",
                "Value" => "Lihat dan kelola server keys Anda di <a href=\"https://dashboard.sandbox.midtrans.com/settings/config_info\">Dasboard Midtrans</a>",
            ),
            'serverKeyTest' => array(
                'FriendlyName' => 'Server Key Test',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter Server key here',
            ),
            'serverKeyLive' => array(
                'FriendlyName' => 'Server Key Live',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter Server key here',
            ),
            'clientKeyTest' => array(
                'FriendlyName' => 'Client Key Test',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter Client key here',
            ),
            'clientKeyLive' => array(
                'FriendlyName' => 'Client Key Live',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter Client key here',
            ),
            'clientId' => array(
                'FriendlyName' => 'Client id notification',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Client id for recieve email notification',
            ),
            'testMode' => array(
                'FriendlyName' => 'Test Mode',
                'Type' => 'yesno',
                'Description' => 'Tick to enable test mode',
            ),
            'instructions' => array(
                'FriendlyName' => 'Payment instructions',
                'Type' => 'textarea',
                'Rows' => '5',
                'Description' => 'The instructions you want displaying to customers who choose this payment method',
                'Default' => $this->getDefaultInstructions(),
            ),
            'emailTemplate' => array(
                'FriendlyName' => 'Email template',
                'Type' => 'dropdown',
                'Options' => $this->getEmailTemplates(),
                'Description' => 'Choose one',
            ),
        ];
    }

    public function link($params)
    {
        /*$invoiceid = $params['invoiceid'];*/
        $invoiceid = $params['invoiceid'];
        $testMode = $params["testMode"];
        $snapJsUrl = $testMode ? "https://app.sandbox.midtrans.com/snap/snap.js" : "https://app.midtrans.com/snap/snap.js";
        $clientKey = $testMode ? $params["clientKeyTest"] : $params["clientKeyLive"];

        /*return view('gopaymidtrans::index', [
            'url' => url("gopaymidtrans/payNow"),
            "url_update" => url("gopaymidtrans"),
            'invoiceid' => $invoiceid,
            'langpaynow' => $params["langpaynow"],
        ]);*/
        
        return view('gopaymidtrans::index', [
            'url' => url("gopaymidtrans/payNow"),
            "url_update" => url("gopaymidtrans"),
            'invoiceid' => $invoiceid,
            'langpaynow' => $params["langpaynow"],
            'amount' => $params['amount'],
            'snapJsUrl' => $snapJsUrl,
            'clientKey' => $clientKey,
        ]);
    }

    private function call($method = 'post', $url = '', $token = '', array $postfield = [])
    {
        $postfield = json_encode($postfield);

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_POSTFIELDS => $postfield,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Accept: application/json',
                'Authorization: Basic '.base64_encode("$token:"),
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return json_decode($response);
    }

    public function payNow(Request $request)
    {
        try {
            $invoiceid = $request->input('invoiceid');

            $invoice = new \App\Helpers\InvoiceClass($invoiceid);
            $params = $invoice->getGatewayInvoiceParams();

            $testMode = $params["testMode"];
            $serverKey = $testMode ? $params["serverKeyTest"] : $params["serverKeyLive"];
            $clientIdNotification = $params["clientId"];
            $clientdetails = $params['clientdetails'];
            $userid = $clientdetails['userid'];
            $name = trim($clientdetails['firstname'].' '.$clientdetails['lastname']);
            /*$baseurl = $testMode ? "https://api.sandbox.midtrans.com/v2/charge" : "https://api.midtrans.com/v2/charge";*/
            $baseurl = $testMode ? "https://app.sandbox.midtrans.com/snap/v1/transactions" : "https://app.midtrans.com/snap/v1/transactions";
           /* $callback_url = url("gopaymidtrans/process_payment");*/

            /*$charge = [
                "payment_type" => "gopay",
                "gopay" => [
                    "enable_callback" => true,
                    "callback_url" => $callback_url,
                ],
                "transaction_details" => [
                    "order_id" => $invoiceid."-".time(),
                    "gross_amount" => ceil($params["amount"]),
                ]
            ];*/
        
           
            $charge = [
                "transaction_details" => [
                    "order_id" => $invoiceid."-".time(),
                    "gross_amount" => ceil($params["amount"]),
                ],
                "enabled_payments" => ["gopay"],
                // "item_details" => $items,
                "customer_details" => [
                    "email" => $clientdetails['email'],
                    "first_name" => $clientdetails['firstname'],
                    "last_name" => $clientdetails['lastname'],
                    "phone" => str_replace(".", "", $clientdetails['phonenumberformatted']),
                ],
            ];
            
            $response = $this->call("post", $baseurl, $serverKey, $charge);
            \Log::debug("gopay midtrans charge", json_decode(json_encode($charge),true));
            \Log::debug("gopay midtrans response", json_decode(json_encode($response),true));
            /*if ($response->status_code != 201) {
                throw new \Exception($response->status_message);
            }*/
            
            if (isset($response->error_messages)) {
                throw new \Exception($response->error_messages);
            }

           /* // get action
            $redirect_url = "";
            foreach ($response->actions as $key => $action) {
                if ($action->name == "deeplink-redirect") {
                    $redirect_url = $action->url;
                    break;
                }
            }*/

            // return response()->json([
            //     'result' => 'success',
            //     'message' => 'ok',
            //     'redirect_url' => $redirect_url,
            //     'data' => $response,
            // ], 200);
            
            return response()->json([
                'result' => 'success',
                'message' => 'ok',
                'redirect_url' => $response->redirect_url,
                'token' => $response->token,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'result' => 'error',
                'message' => $e->getMessage(),
            ]);
        }
    }

    public function process_payment(Request $request)
    {
        try {
            $auth = Auth::guard('web')->user();
            $userid = $auth ? $auth->id : 0;
            $order_id = $request->input('order_id');
            $order_id_explode = explode("-", $order_id);
            $invoiceid = $order_id_explode[0] ?? 0;

            $invoice = new \App\Helpers\InvoiceClass($invoiceid);
            $params = $invoice->getGatewayInvoiceParams();

            // check kepemilikan invoice
            if ($params["clientdetails"]["userid"] != $userid) {
                return abort(403);
            }

            // check status
            if ($invoice->getData("status") == "Paid") {
                return redirect($params['returnurl']);
            }

            return view("gopaymidtrans::process_payment", [
                "returnurl" => $params['returnurl'],
            ]);
        } catch (\Exception $e) {
            return view("gopaymidtrans::error_process_payment", [
                "message" => $e->getMessage(),
            ]);
        }

    }

    // not used
    public function callback(Request $request)
    {
        \Log::debug("=== callback gopay");
        \Log::debug($request->all());
    }

    public function index(Request $request)
    {
        $postData = array(
            'invoiceid' => $request->input('id'),
        );
        $response = (new \App\Helpers\HelperApi)->localAPI('GetInvoice', $postData);
        if ($response['result'] == 'success') {
            if($response['status'] == 'Paid'){
                return response()->json(['status' => true], 200);
            }else{
                return response()->json(['status' => false], 200);
            }
        } else {
            return response()->json(['status' => false], 200);
        }
    }

    private function getDefaultInstructions()
    {
        return '
        under construction
        '; 
    }

    private function getEmailTemplates()
    {
        $data = [];
        $data[""] = "-- None --";
        $emailTemplates = \Illuminate\Support\Facades\DB::table("tblemailtemplates")->where(["type" => "invoice", "custom" => "1"])->get();
        foreach ($emailTemplates as $emailTemplate) {
            $data[$emailTemplate->name] = $emailTemplate->name;
        }

        return $data;
    }
}
