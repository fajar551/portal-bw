<?php

return [
    'name' => 'Shopeepayxendit'
];
