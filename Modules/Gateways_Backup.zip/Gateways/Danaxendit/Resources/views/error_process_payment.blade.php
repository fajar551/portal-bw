<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Error Payment</title>
</head>
<body>
    <p>{{$message}}</p>
    <p><a href="{{url('/')}}">Back to Home</a></p>
</body>
</html>
