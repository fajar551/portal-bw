<?php

return [
    'name' => 'Ovoxendit'
];
