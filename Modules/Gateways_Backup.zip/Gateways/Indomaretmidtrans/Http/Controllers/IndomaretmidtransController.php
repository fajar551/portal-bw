<?php

namespace Modules\Gateways\Indomaretmidtrans\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use DB, Auth;

class IndomaretmidtransController extends Controller
{
    function MetaData()
    {
        return array(
            'DisplayName' => 'Indomaret Midtrans',
            'APIVersion' => '1.1', // Use API Version 1.1
            'DisableLocalCreditCardInput' => true,
            'TokenisedStorage' => false,
        );
    }

    function config()
    {
        return [
            'FriendlyName' => array(
                'Type' => 'System',
                'Value' => 'Indomaret Midtrans',
            ),
            "UsageNotes" => array(
                "Type" => "System",
                "Value" => "Lihat dan kelola server keys Anda di <a href=\"https://dashboard.sandbox.midtrans.com/settings/config_info\">Dasboard Midtrans</a>",
            ),
            'serverKeyTest' => array(
                'FriendlyName' => 'Server Key Test',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter Server key here',
            ),
            'serverKeyLive' => array(
                'FriendlyName' => 'Server Key Live',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter Server key here',
            ),
            'clientId' => array(
                'FriendlyName' => 'Client id notification',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Client id for recieve email notification',
            ),
            'testMode' => array(
                'FriendlyName' => 'Test Mode',
                'Type' => 'yesno',
                'Description' => 'Tick to enable test mode',
            ),
            'instructions' => array(
                'FriendlyName' => 'Payment instructions',
                'Type' => 'textarea',
                'Rows' => '5',
                'Description' => 'The instructions you want displaying to customers who choose this payment method',
                'Default' => $this->getDefaultInstructions(),
            ),
            'emailTemplate' => array(
                'FriendlyName' => 'Email template',
                'Type' => 'dropdown',
                'Options' => $this->getEmailTemplates(),
                'Description' => 'Choose one',
            ),
        ];
    }

    public function link($params)
    {
        $invoiceid = $params['invoiceid'];

        return view('indomaretmidtrans::index', [
            'url' => url("indomaretmidtrans/payNow"),
            "url_update" => url("indomaretmidtrans"),
            'invoiceid' => $invoiceid,
            'langpaynow' => $params["langpaynow"],
        ]);
    }

    private function call($method = 'post', $url = '', $token = '', array $postfield = [])
    {
        $postfield = json_encode($postfield);

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_POSTFIELDS => $postfield,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Accept: application/json',
                'Authorization: Basic '.base64_encode("$token:"),
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return json_decode($response);
    }

    private function alertBox($type, $message)
    {
        $alert = '<div class="alert alert-%s">%s</div>';
        return sprintf($alert, $type, $message);
    }

    public function payNow(Request $request)
    {
        try {
            $invoiceid = $request->input('invoiceid');

            $invoice = new \App\Helpers\InvoiceClass($invoiceid);
            $params = $invoice->getGatewayInvoiceParams();

            $testMode = $params["testMode"];
            $serverKey = $testMode ? $params["serverKeyTest"] : $params["serverKeyLive"];
            $clientIdNotification = $params["clientId"];
            $clientdetails = $params['clientdetails'];
            $userid = $clientdetails['userid'];
            $invoiceid = $params['invoiceid'];
            $name = trim($clientdetails['firstname'].' '.$clientdetails['lastname']);
            $baseurl = $testMode ? "https://api.sandbox.midtrans.com/v2/charge" : "https://api.midtrans.com/v2/charge";

            // change this
            $message_link = "Kode Bayar Indomaret Anda: <strong>%s</strong>";

            $items = [];
            foreach ($invoice->getLineItems(true) as $key => $invoiceitem) {
                $items[] = [
                    'id' => (string) $invoiceitem['relid'],
                    'price' => round($invoiceitem['rawamount']),
                    'quantity' => 1,
                    'name' => $invoiceitem['description'],
                    'category' => !empty($invoiceitem['type']) ? $invoiceitem['type'] : 'Custom',
                    'merchant_name' => $params["companyname"],
                ];
            }

            $charge = [
                "payment_type" => "cstore",
                "transaction_details" => [
                    "order_id" => $invoiceid."-".time(),
                    "gross_amount" => round($params["amount"], 2),
                ],
                "customer_details" => [
                    "email" => $clientdetails['email'],
                    "first_name" => $clientdetails['firstname'],
                    "last_name" => $clientdetails['lastname'],
                    "phone" => str_replace(".", "", $clientdetails['phonenumberformatted']),
                ],
                "item_details" => $items,
                "cstore" => [
                    "store" => "indomaret",
                    "message" => $params["description"]
                ],
            ];
            $response = $this->call("post", $baseurl, $serverKey, $charge);
            \Log::debug("== indomaret midtrans response");
            \Log::debug(json_decode(json_encode($response), true));
            if ($response->status_code != 201) {
                throw new \Exception($response->status_message);
            }

            $message = sprintf($message_link, $response->payment_code);
            return response()->json([
                'result' => 'success',
                'message' => "ok",
                'html' => $this->alertBox("success", $message),
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'result' => 'error',
                'message' => $e->getMessage(),
                'html' => $this->alertBox("danger", $e->getMessage()),
            ]);
        }
    }

    public function index(Request $request)
    {
        $postData = array(
            'invoiceid' => $request->input('id'),
        );
        $response = (new \App\Helpers\HelperApi)->localAPI('GetInvoice', $postData);
        if ($response['result'] == 'success') {
            if($response['status'] == 'Paid'){
                return response()->json(['status' => true], 200);
            }else{
                return response()->json(['status' => false], 200);
            }
        } else {
            return response()->json(['status' => false], 200);
        }
    }

    private function getDefaultInstructions()
    {
        return '
        under construction
        '; 
    }

    private function getEmailTemplates()
    {
        $data = [];
        $data[""] = "-- None --";
        $emailTemplates = \Illuminate\Support\Facades\DB::table("tblemailtemplates")->where(["type" => "invoice", "custom" => "1"])->get();
        foreach ($emailTemplates as $emailTemplate) {
            $data[$emailTemplate->name] = $emailTemplate->name;
        }

        return $data;
    }
}
