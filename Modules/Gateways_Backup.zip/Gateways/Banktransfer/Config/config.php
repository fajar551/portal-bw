<?php

return [
    'name' => 'Banktransfer'
];
