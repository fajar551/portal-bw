<div class="alert alert-success">
    {!!$message!!}
    <br/>Lihat <a href="" data-toggle="modal" data-target="#myModal">cara bayar</a>
</div>

{{-- modal cara bayar --}}
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="myModalLabel">Cara Bayar</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body text-left">
          {!!$instructions!!}
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
        </div>
      </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        setInterval(update, 5000);
    });
    function update() {
        $.ajax({
            type : 'GET',
            url : "{{$url_update}}",
            data: {id: "{{$invoiceid}}", _token: "{{csrf_token()}}"},
            success : function(data){
                if(data.status){
                    location.reload();
                }	
            },
        });
    };
</script>
