<?php

namespace Modules\Gateways\Qrisxendit\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class QrisxenditController extends Controller
{
    function MetaData()
    {
        return array(
            'DisplayName' => 'Qris Xendit',
            'APIVersion' => '1.1', // Use API Version 1.1
            'DisableLocalCreditCardInput' => true,
            'TokenisedStorage' => false,
        );
    }

    function config()
    {
        return [
            'FriendlyName' => array(
                'Type' => 'System',
                'Value' => 'Qris Xendit',
            ),
            "UsageNotes" => array(
                "Type" => "System",
                "Value" => "Lihat dan kelola secret keys Anda di <a href=\"https://dashboard.xendit.co/settings/developers#api-keys\">Dasboard Xendit</a>",
            ),
            'secretKeyTest' => array(
                'FriendlyName' => 'Secret Key Test',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter secret key here',
            ),
            'secretKeyLive' => array(
                'FriendlyName' => 'Secret Key Live',
                'Type' => 'password',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter secret key here',
            ),
            'tokenCallbackTest' => array(
                'FriendlyName' => 'Token verifikasi callback test',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter your token here',
            ),
            'tokenCallbackLive' => array(
                'FriendlyName' => 'Token verifikasi callback live',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Enter your token here',
            ),
            'clientId' => array(
                'FriendlyName' => 'Client id notification',
                'Type' => 'text',
                'Size' => '25',
                'Default' => '',
                'Description' => 'Client id for recieve email notification',
            ),
            'testMode' => array(
                'FriendlyName' => 'Test Mode',
                'Type' => 'yesno',
                'Description' => 'Tick to enable test mode',
            ),
            'instructions' => array(
                'FriendlyName' => 'Payment instructions',
                'Type' => 'textarea',
                'Rows' => '5',
                'Description' => 'The instructions you want displaying to customers who choose this payment method',
                'Default' => $this->getDefaultInstructions(),
            ),
            'emailTemplate' => array(
                'FriendlyName' => 'Email template',
                'Type' => 'dropdown',
                'Options' => $this->getEmailTemplates(),
                'Description' => 'Choose one',
            ),
        ];
    }

    public function link($params = [])
    {
        $testMode = $params["testMode"];
        $secretKey = $testMode ? $params["secretKeyTest"] : $params["secretKeyLive"];
        $tokenModule = $testMode ? $params["tokenCallbackTest"] : $params["tokenCallbackLive"];
        $clientdetails = $params['clientdetails'];
        $userid = $clientdetails['userid'];
        $invoiceid = $params['invoiceid'];
        $name = trim($clientdetails['firstname'].' '.$clientdetails['lastname']);
        $url = "https://api.xendit.co/qr_codes";

        try {
            $chargeQrParams = [
                'external_id' => $invoiceid.'-'.time(),
                'type' => 'DYNAMIC',
                'callback_url' => url("qrisxendit/callback"),
                'amount' => ceil($params['amount']),
                'metadata' => [
                    'invoiceid' => (string) $invoiceid,
                    'userid' => (string) $userid,
                    'gateway' => 'qrisxendit',
                    'token' => (string) $tokenModule,
                ],
            ];
            \Log::info("QRIS charge", json_decode(json_encode($chargeQrParams), true));
            $response = $this->call("post", $url, $secretKey, $chargeQrParams);
            \Log::debug("===link qrcode");
            \Log::debug(json_decode(json_encode($response), true));
            if (isset($response->error_code)) {
                throw new \Exception($response->message);
            }

            return view('qrisxendit::index', [
                'invoiceid' => $invoiceid,
                'qrcode' => $response->qr_string,
            ]);
        } catch (\Exception $e) {
            return $e->getMessage();
        }
    }

    private function call($method = 'post', $url = '', $token = '', array $postfield = [])
    {
        $postfield = json_encode($postfield);

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_POSTFIELDS => $postfield,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: Basic '.base64_encode("$token:"),
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return json_decode($response);
    }

    public function callback(Request $request)
    {
        try {
            $token = $request->header('x-callback-token');
            $callback = json_decode(file_get_contents('php://input'), true);
            \Log::debug("=== callback qr dibayar");
            \Log::debug($callback);

            $gateway = "qrisxendit";
            $params = \App\Helpers\Gateway::getGatewayVariables($gateway);
            $testMode = $params["testMode"];
            $secretKey = $testMode ? $params["secretKeyTest"] : $params["secretKeyLive"];
            $tokenModule = $testMode ? $params["tokenCallbackTest"] : $params["tokenCallbackLive"];
            $clientIdNotification = $params["clientId"];

            // verify token
            if ($token != $tokenModule) {
                throw new \Exception("Callback token is not valid");
            }

            // get callback data
            $id = $callback["id"];
            $status = $callback["status"];
            $amount = $callback["amount"];
            $external_id = $callback["qr_code"]["external_id"];
            $userid = $callback["qr_code"]["metadata"]["userid"];
            $invoiceid = $callback["qr_code"]["metadata"]["invoiceid"];
            $tXid = $external_id;

            // cek qr
            // $response = $this->call("get", "https://api.xendit.co/qr_codes/$external_id", $secretKey);
            // \Log::debug("===link qrcode callback");
            // \Log::debug(json_decode(json_encode($response), true));
            // if (isset($response->error_code)) {
            //     throw new \Exception($response->message);
            // }

            // check status
            if ($status != "COMPLETED") {
                throw new \Exception("Status not COMPLETED");
            }

            \App\Helpers\Gateway::logTransaction($gateway, $callback, $status);
            $transaction = \App\Models\Account::where("transid", $tXid);
            $payment_num_rows_transaction_count = $transaction->count();

            // jika transaksi belum ada
            if ($payment_num_rows_transaction_count <= 0) {
                $values["customtype"] = "general";
                $values["customsubject"] = "Ada Pembayaran Masuk ke Qris Xendit Relabs, Untuk No Invoice: ".$invoiceid.", Txid:".$tXid;
                $values["custommessage"] = "Silakan di cek di https://dashboard.xendit.co/</nowiki>";
                $values["id"] = $clientIdNotification;
                (new \App\Helpers\HelperApi)->localAPI('SendEmail', $values);
                
                \App\Helpers\Invoice::addInvoicePayment(
                    $invoiceid,
                    $tXid,
                    $amount,
                    '',//Payment Fee
                    $gateway
                );

                return response()->json([
                    'result' => 'success',
                    'message' => "ok",
                ], 200);
            }
        } catch (\Exception $e) {
            $message = "Callback xendit qr error: ". $e->getMessage();
            \App\Helpers\LogActivity::Save($message);
            return response()->json([
                'result' => 'error',
                'message' => $message,
            ], 400);
        }
    }

    public function ajax(Request $request)
    {
        $postData = array(
            'invoiceid' => $request->input('id'),
        );
        $response = (new \App\Helpers\HelperApi)->localAPI('GetInvoice', $postData);
        if ($response['result'] == 'success') {
            if($response['status'] == 'Paid'){
                return response()->json(['status' => true], 200);
            }else{
                return response()->json(['status' => false], 200);
            }
        } else {
            return response()->json(['status' => false], 200);
        }
    }

    private function getDefaultInstructions()
    {
        return '
        under construction
        '; 
    }

    private function getEmailTemplates()
    {
        $data = [];
        $data[""] = "-- None --";
        $emailTemplates = \Illuminate\Support\Facades\DB::table("tblemailtemplates")->where(["type" => "invoice", "custom" => "1"])->get();
        foreach ($emailTemplates as $emailTemplate) {
            $data[$emailTemplate->name] = $emailTemplate->name;
        }

        return $data;
    }
}
