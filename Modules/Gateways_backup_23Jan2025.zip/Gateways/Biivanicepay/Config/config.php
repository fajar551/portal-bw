<?php

return [
    'name' => 'Biivanicepay'
];
