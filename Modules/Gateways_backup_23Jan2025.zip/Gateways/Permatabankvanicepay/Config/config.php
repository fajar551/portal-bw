<?php

return [
    'name' => 'Permatabankvanicepay'
];
