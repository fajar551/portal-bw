<?php

return [
    'name' => 'Paypal'
];
