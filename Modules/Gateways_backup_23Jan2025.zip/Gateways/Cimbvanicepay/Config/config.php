<?php

return [
    'name' => 'Cimbvanicepay'
];
